import os
import pandas as pd

# ----------------------------------------------------
# [인수인계 규격] 폴더 경로 및 검수자 지정
# ----------------------------------------------------
APPROVED_DIR = "./images/approved"
PENDING_DIR = "./images/pending"
DUPLICATES_DIR = "./images/duplicates"

OUTPUT_FILE = "./groups_demo.csv"
REVIEWER_NAME = "박준현"

def get_files(directory):
    if not os.path.exists(directory): return []
    return [f for f in os.listdir(directory) if f.endswith(('.jpg', '.jpeg', '.png'))]

approved_list = get_files(APPROVED_DIR)
pending_list = get_files(PENDING_DIR)
duplicate_list = get_files(DUPLICATES_DIR)

groups_data = []

# 1. Approved: 단독 고유 ID 부여
for f in approved_list:
    groups_data.append({
        "image_id": f,
        "group_id": f"solo_{os.path.splitext(f)[0]}",
        "reviewer": REVIEWER_NAME,
        "evidence": "[검수 완료] 박스 배치 점수 기준 미달로 단독 이미지 확정"
    })

# 2. Pending: ★중요★ 일괄 동일 ID 부여 (툴킷이 하나의 그룹으로 인식해 통째로 움직이게 만듦)
for f in pending_list:
    groups_data.append({
        "image_id": f,
        "group_id": "G_ISOLATE_PENDING_POOL",
        "reviewer": REVIEWER_NAME,
        "evidence": "[검수 필요] 다음 회의에서 검수 후 데이터 처리 예정."
    })

# 3. Duplicates: 확정 4대 중복 그룹 매핑
for f in duplicate_list:
    if "d--31" in f or "d--32" in f:
        g_id = "G_D_31_32"
    elif "d--39" in f or "d--40" in f:
        g_id = "G_D_39_40"
    elif "d--1" in f or "d--28" in f:
        g_id = "G_D_1_28"
    elif "d--12" in f or "d--30" in f:
        g_id = "G_D_12_30"
    else:
        g_id = "G_D_UNKNOWN"
        
    groups_data.append({
        "image_id": f,
        "group_id": g_id,
        "reviewer": REVIEWER_NAME,
        "evidence": f"[확정 중복] {g_id} 그룹 레이아웃 IoU 매칭 완료"
    })

df = pd.DataFrame(groups_data)
df.to_csv(OUTPUT_FILE, index=False)
print(f"매뉴얼 규격 groups 파일 생성 완료: {OUTPUT_FILE}")